﻿namespace ProyectoPED_1
{
    partial class FrmGestionLibros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGestionLibros));
			this.DGVLibros = new MetroFramework.Controls.MetroGrid();
			this.btnAgregarLibro = new MetroFramework.Controls.MetroButton();
			this.groupBox1 = new MetroFramework.Controls.MetroPanel();
			this.txtAñoPublicado = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
			this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
			this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
			this.txtAutor = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
			this.chkDisponible = new MetroFramework.Controls.MetroCheckBox();
			this.txtTitulo = new MetroFramework.Controls.MetroTextBox();
			this.btnRegresar = new MetroFramework.Controls.MetroButton();
			this.btnConsultarLibros = new MetroFramework.Controls.MetroButton();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.DGVLibros)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// DGVLibros
			// 
			this.DGVLibros.AllowUserToResizeRows = false;
			this.DGVLibros.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			this.DGVLibros.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.DGVLibros.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DGVLibros.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
			this.DGVLibros.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
			this.DGVLibros.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVLibros.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
			this.DGVLibros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.DGVLibros.DefaultCellStyle = dataGridViewCellStyle5;
			this.DGVLibros.EnableHeadersVisualStyles = false;
			this.DGVLibros.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.DGVLibros.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.DGVLibros.Location = new System.Drawing.Point(298, 29);
			this.DGVLibros.Name = "DGVLibros";
			this.DGVLibros.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
			dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVLibros.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
			this.DGVLibros.RowHeadersWidth = 51;
			this.DGVLibros.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.DGVLibros.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DGVLibros.Size = new System.Drawing.Size(696, 412);
			this.DGVLibros.TabIndex = 5;
			this.DGVLibros.UseCustomBackColor = true;
			this.DGVLibros.UseCustomForeColor = true;
			this.DGVLibros.UseStyleColors = true;
			// 
			// btnAgregarLibro
			// 
			this.btnAgregarLibro.BackColor = System.Drawing.SystemColors.MenuHighlight;
			this.btnAgregarLibro.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.btnAgregarLibro.ForeColor = System.Drawing.SystemColors.Control;
			this.btnAgregarLibro.Location = new System.Drawing.Point(72, 237);
			this.btnAgregarLibro.Name = "btnAgregarLibro";
			this.btnAgregarLibro.Size = new System.Drawing.Size(121, 38);
			this.btnAgregarLibro.TabIndex = 16;
			this.btnAgregarLibro.Text = "AGREGAR";
			this.btnAgregarLibro.UseCustomBackColor = true;
			this.btnAgregarLibro.UseCustomForeColor = true;
			this.btnAgregarLibro.UseMnemonic = false;
			this.btnAgregarLibro.UseSelectable = true;
			this.btnAgregarLibro.UseStyleColors = true;
			this.btnAgregarLibro.Click += new System.EventHandler(this.btnAgregarLibro_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.txtAñoPublicado);
			this.groupBox1.Controls.Add(this.metroLabel4);
			this.groupBox1.Controls.Add(this.metroLabel2);
			this.groupBox1.Controls.Add(this.metroLabel3);
			this.groupBox1.Controls.Add(this.txtAutor);
			this.groupBox1.Controls.Add(this.metroLabel1);
			this.groupBox1.Controls.Add(this.chkDisponible);
			this.groupBox1.Controls.Add(this.txtTitulo);
			this.groupBox1.Controls.Add(this.btnAgregarLibro);
			this.groupBox1.HorizontalScrollbarBarColor = true;
			this.groupBox1.HorizontalScrollbarHighlightOnWheel = false;
			this.groupBox1.HorizontalScrollbarSize = 10;
			this.groupBox1.Location = new System.Drawing.Point(18, 71);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(262, 292);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.VerticalScrollbarBarColor = true;
			this.groupBox1.VerticalScrollbarHighlightOnWheel = false;
			this.groupBox1.VerticalScrollbarSize = 10;
			// 
			// txtAñoPublicado
			// 
			// 
			// 
			// 
			this.txtAñoPublicado.CustomButton.Image = null;
			this.txtAñoPublicado.CustomButton.Location = new System.Drawing.Point(57, 2);
			this.txtAñoPublicado.CustomButton.Name = "";
			this.txtAñoPublicado.CustomButton.Size = new System.Drawing.Size(14, 15);
			this.txtAñoPublicado.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtAñoPublicado.CustomButton.TabIndex = 1;
			this.txtAñoPublicado.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtAñoPublicado.CustomButton.UseSelectable = true;
			this.txtAñoPublicado.CustomButton.Visible = false;
			this.txtAñoPublicado.Lines = new string[0];
			this.txtAñoPublicado.Location = new System.Drawing.Point(20, 133);
			this.txtAñoPublicado.MaxLength = 32767;
			this.txtAñoPublicado.Name = "txtAñoPublicado";
			this.txtAñoPublicado.PasswordChar = '\0';
			this.txtAñoPublicado.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtAñoPublicado.SelectedText = "";
			this.txtAñoPublicado.SelectionLength = 0;
			this.txtAñoPublicado.SelectionStart = 0;
			this.txtAñoPublicado.ShortcutsEnabled = true;
			this.txtAñoPublicado.Size = new System.Drawing.Size(98, 24);
			this.txtAñoPublicado.TabIndex = 22;
			this.txtAñoPublicado.UseSelectable = true;
			this.txtAñoPublicado.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtAñoPublicado.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel4
			// 
			this.metroLabel4.AutoSize = true;
			this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel4.Location = new System.Drawing.Point(20, 192);
			this.metroLabel4.Name = "metroLabel4";
			this.metroLabel4.Size = new System.Drawing.Size(120, 19);
			this.metroLabel4.TabIndex = 21;
			this.metroLabel4.Text = "DISPONIBILIDAD";
			this.metroLabel4.UseStyleColors = true;
			// 
			// metroLabel2
			// 
			this.metroLabel2.AutoSize = true;
			this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel2.Location = new System.Drawing.Point(19, 62);
			this.metroLabel2.Name = "metroLabel2";
			this.metroLabel2.Size = new System.Drawing.Size(74, 25);
			this.metroLabel2.TabIndex = 19;
			this.metroLabel2.Text = "AUTOR";
			this.metroLabel2.UseStyleColors = true;
			// 
			// metroLabel3
			// 
			this.metroLabel3.AutoSize = true;
			this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel3.Location = new System.Drawing.Point(20, 114);
			this.metroLabel3.Name = "metroLabel3";
			this.metroLabel3.Size = new System.Drawing.Size(159, 19);
			this.metroLabel3.TabIndex = 20;
			this.metroLabel3.Text = "AÑO DE PUBLICACION";
			this.metroLabel3.UseStyleColors = true;
			// 
			// txtAutor
			// 
			// 
			// 
			// 
			this.txtAutor.CustomButton.Image = null;
			this.txtAutor.CustomButton.Location = new System.Drawing.Point(88, 2);
			this.txtAutor.CustomButton.Name = "";
			this.txtAutor.CustomButton.Size = new System.Drawing.Size(14, 15);
			this.txtAutor.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtAutor.CustomButton.TabIndex = 1;
			this.txtAutor.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtAutor.CustomButton.UseSelectable = true;
			this.txtAutor.CustomButton.Visible = false;
			this.txtAutor.Lines = new string[0];
			this.txtAutor.Location = new System.Drawing.Point(111, 62);
			this.txtAutor.MaxLength = 32767;
			this.txtAutor.Name = "txtAutor";
			this.txtAutor.PasswordChar = '\0';
			this.txtAutor.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtAutor.SelectedText = "";
			this.txtAutor.SelectionLength = 0;
			this.txtAutor.SelectionStart = 0;
			this.txtAutor.ShortcutsEnabled = true;
			this.txtAutor.Size = new System.Drawing.Size(139, 24);
			this.txtAutor.TabIndex = 17;
			this.txtAutor.UseSelectable = true;
			this.txtAutor.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtAutor.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel1
			// 
			this.metroLabel1.AutoSize = true;
			this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel1.Location = new System.Drawing.Point(19, 20);
			this.metroLabel1.Name = "metroLabel1";
			this.metroLabel1.Size = new System.Drawing.Size(76, 25);
			this.metroLabel1.TabIndex = 18;
			this.metroLabel1.Text = "TITULO";
			this.metroLabel1.UseStyleColors = true;
			// 
			// chkDisponible
			// 
			this.chkDisponible.AutoSize = true;
			this.chkDisponible.FontWeight = MetroFramework.MetroCheckBoxWeight.Bold;
			this.chkDisponible.Location = new System.Drawing.Point(174, 192);
			this.chkDisponible.Name = "chkDisponible";
			this.chkDisponible.Size = new System.Drawing.Size(55, 15);
			this.chkDisponible.TabIndex = 13;
			this.chkDisponible.Text = "LIBRE";
			this.chkDisponible.UseSelectable = true;
			this.chkDisponible.UseStyleColors = true;
			// 
			// txtTitulo
			// 
			// 
			// 
			// 
			this.txtTitulo.CustomButton.Image = null;
			this.txtTitulo.CustomButton.Location = new System.Drawing.Point(86, 2);
			this.txtTitulo.CustomButton.Name = "";
			this.txtTitulo.CustomButton.Size = new System.Drawing.Size(16, 17);
			this.txtTitulo.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtTitulo.CustomButton.TabIndex = 1;
			this.txtTitulo.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtTitulo.CustomButton.UseSelectable = true;
			this.txtTitulo.CustomButton.Visible = false;
			this.txtTitulo.Lines = new string[0];
			this.txtTitulo.Location = new System.Drawing.Point(111, 19);
			this.txtTitulo.MaxLength = 32767;
			this.txtTitulo.Name = "txtTitulo";
			this.txtTitulo.PasswordChar = '\0';
			this.txtTitulo.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtTitulo.SelectedText = "";
			this.txtTitulo.SelectionLength = 0;
			this.txtTitulo.SelectionStart = 0;
			this.txtTitulo.ShortcutsEnabled = true;
			this.txtTitulo.Size = new System.Drawing.Size(139, 26);
			this.txtTitulo.TabIndex = 16;
			this.txtTitulo.UseSelectable = true;
			this.txtTitulo.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtTitulo.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// btnRegresar
			// 
			this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
			this.btnRegresar.FontSize = MetroFramework.MetroButtonSize.Medium;
			this.btnRegresar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.btnRegresar.Location = new System.Drawing.Point(869, 467);
			this.btnRegresar.Name = "btnRegresar";
			this.btnRegresar.Size = new System.Drawing.Size(125, 37);
			this.btnRegresar.TabIndex = 17;
			this.btnRegresar.Text = "SALIR";
			this.btnRegresar.UseCustomBackColor = true;
			this.btnRegresar.UseCustomForeColor = true;
			this.btnRegresar.UseSelectable = true;
			this.btnRegresar.UseStyleColors = true;
			this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
			// 
			// btnConsultarLibros
			// 
			this.btnConsultarLibros.BackColor = System.Drawing.SystemColors.MenuHighlight;
			this.btnConsultarLibros.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.btnConsultarLibros.ForeColor = System.Drawing.SystemColors.Control;
			this.btnConsultarLibros.Location = new System.Drawing.Point(298, 466);
			this.btnConsultarLibros.Name = "btnConsultarLibros";
			this.btnConsultarLibros.Size = new System.Drawing.Size(178, 38);
			this.btnConsultarLibros.TabIndex = 22;
			this.btnConsultarLibros.Text = "CONSULTA DE LIBROS";
			this.btnConsultarLibros.UseCustomBackColor = true;
			this.btnConsultarLibros.UseCustomForeColor = true;
			this.btnConsultarLibros.UseMnemonic = false;
			this.btnConsultarLibros.UseSelectable = true;
			this.btnConsultarLibros.UseStyleColors = true;
			this.btnConsultarLibros.Click += new System.EventHandler(this.btnConsultarLibros_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(-16, 369);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(202, 186);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 23;
			this.pictureBox1.TabStop = false;
			// 
			// FrmGestionLibros
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1018, 523);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btnConsultarLibros);
			this.Controls.Add(this.btnRegresar);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.DGVLibros);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "FrmGestionLibros";
			this.Padding = new System.Windows.Forms.Padding(15, 60, 15, 16);
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Gestion De Libros";
			this.Load += new System.EventHandler(this.FrmGestionLibros_Load);
			((System.ComponentModel.ISupportInitialize)(this.DGVLibros)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion
		private MetroFramework.Controls.MetroGrid DGVLibros;
		private MetroFramework.Controls.MetroButton btnAgregarLibro;
		private MetroFramework.Controls.MetroPanel groupBox1;
		private MetroFramework.Controls.MetroCheckBox chkDisponible;
		private MetroFramework.Controls.MetroTextBox txtAutor;
		private MetroFramework.Controls.MetroTextBox txtTitulo;
		private MetroFramework.Controls.MetroLabel metroLabel1;
		private MetroFramework.Controls.MetroLabel metroLabel2;
		private MetroFramework.Controls.MetroLabel metroLabel3;
		private MetroFramework.Controls.MetroLabel metroLabel4;
		private MetroFramework.Controls.MetroButton btnRegresar;
        private MetroFramework.Controls.MetroButton btnConsultarLibros;
        private MetroFramework.Controls.MetroTextBox txtAñoPublicado;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}
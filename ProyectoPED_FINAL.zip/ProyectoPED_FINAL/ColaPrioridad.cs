﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using static ProyectoPED_1.Reserva;

namespace ProyectoPED_1
{
    internal class ColaPrioridad
    {
        private Reserva primero;
        private int ultimoID;
        private string rutaArchivo;

        public ColaPrioridad()
        {
            primero = null;
            ultimoID = 0;
            rutaArchivo = Path.Combine(Application.StartupPath, "reservas.txt");

            GuardarEnArchivo();
        }

        private int GenerarID()
        {
            return ++ultimoID;
        }

        //metodo principal para agregar una reserva siguiendo la jerarquia de prioridad
        public void AgregarReserva(int libriID, string nombreuser, TipoPrioridad prioridad,
            string tipouser, DateTime fechaInicio, DateTime fechaFin)
        {
            int nuevoID = GenerarID();
            Reserva nuevaReserva = new Reserva(nuevoID, libriID, nombreuser, prioridad,
                tipouser, fechaInicio, fechaFin);

            //si la cola esta vacia o la nueva reserva tiene mayor prioridad que la primera:
            if (primero == null || prioridad < primero.Prioridad)
            {
                nuevaReserva.Siguiente = primero;
                primero = nuevaReserva;
                return;
            }

            //Si tiene la misma prioridad que el primero, se ordena por fecha
            if (prioridad == primero.Prioridad)
            {
                if (nuevaReserva.FechaSolicitud <= primero.FechaSolicitud)
                {
                    nuevaReserva.Siguiente = primero;
                    primero = nuevaReserva;
                    return;
                }
            }

            //Busca la posicion correcta en la cola:
            Reserva actual = primero;
            while (actual.Siguiente != null)
            {
                //Si la siguiente reserva tiene menor prioridad
                if (actual.Siguiente.Prioridad > prioridad)
                {
                    nuevaReserva.Siguiente = actual.Siguiente;
                    actual.Siguiente = nuevaReserva;
                    return;
                }
                //si tienen la misma prioridad, se vuelve a ordenar por fecha
                else if (actual.Siguiente.Prioridad == prioridad)
                {
                    if (nuevaReserva.FechaSolicitud <= actual.Siguiente.FechaSolicitud)
                    {
                        nuevaReserva.Siguiente = actual.Siguiente;
                        actual.Siguiente = nuevaReserva;
                        return;
                    }
                }
                actual = actual.Siguiente;
            }

            //si se llega aqui, la nueva reserva va hasta el final:
            actual.Siguiente = nuevaReserva;
        }

        //Metodo para procesar la reserva con mayor prioridad:

        public Reserva ProcesarReserva()
        {
            if (primero == null)
                return null;

            Reserva procesada = primero;
            primero = primero.Siguiente;
            GuardarEnArchivo();
            return procesada;
        }

        //metodo para ver la siguiente reserva sin procesarla:
        public Reserva VerSiguiente()
        {
            return primero;
        }

        //Buscar reservas por libro:
        public List<Reserva> BuscarPorLibro(int libroID)
        {
            List<Reserva> reservaLibro = new List<Reserva>();
            Reserva actual = primero;

            while (actual != null)
            {
                if (actual.LibroID == libroID)
                {
                    reservaLibro.Add(actual);
                }
                actual = actual.Siguiente;
            }
            return reservaLibro;
        }

        //Busca reservas por usuario
        public List<Reserva> ReservaUser(string nombreUser)
        {
            List<Reserva> reservaUser = new List<Reserva>();
            Reserva actual = null;

            while (actual != null)
            {
                if (actual.NombreUsuario.Equals(nombreUser, StringComparison.OrdinalIgnoreCase))
                {
                    reservaUser.Add(actual);
                }
                actual = actual.Siguiente;
            }

            return reservaUser;
        }

        //Eliminar una reserva especifica por ID:
        public bool EliminarReserva(int reservaID)
        {
            if (primero == null)
                return false;

            //caso especial: eliminar el primero
            if (primero.ID == reservaID)
            {
                primero = primero.Siguiente;
                GuardarEnArchivo();
                return true;
            }

            //Busca la reserva a eliminar:
            Reserva actual = primero;
            while (actual.Siguiente != null)
            {
                if (actual.Siguiente.ID == reservaID)
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    GuardarEnArchivo();
                    return true;
                }
                actual = actual.Siguiente;
            }
            return false;
        }

        //Cancelar todas las reservas de un libro (cuando se elimine un libro)
        public bool CancelarReservasLibro(int libroID)
        {
            bool reservasEliminadas = false;
            Reserva actual = primero;
            Reserva anterior = null;

            while (actual != null)
            {
                if (actual.LibroID == libroID)
                {
                    if (anterior == null)
                    {
                        primero = actual.Siguiente;
                    }
                    else
                    {
                        anterior.Siguiente = actual.Siguiente;
                    }
                    reservasEliminadas = true;
                }
                else
                {
                    anterior = actual;
                }
                actual = actual.Siguiente;
            }
            if (reservasEliminadas)
            {
                GuardarEnArchivo();
            }

            return reservasEliminadas;
        }

        //Obtiene todas las reservas para mostrar en DGV
        public List<ReservaDTO> ObtenerReservas()
        {
            List<ReservaDTO> reservas = new List<ReservaDTO>();
            Reserva actual = primero;
            int posicion = 1;

            while (actual != null)
            {
                TimeSpan tiempoespera = DateTime.Now - actual.FechaSolicitud;
                string tiempoEsperado = "";

                if (tiempoespera.Days > 0)
                    tiempoEsperado = $"{tiempoespera.Days} dias ";
                else if (tiempoespera.Hours > 0)
                    tiempoEsperado = $"{tiempoespera.Hours} horas";
                else
                    tiempoEsperado = $"{tiempoespera.Minutes} minutos";

                reservas.Add(new ReservaDTO
                {
                    ID = actual.ID,
                    LibroID = actual.LibroID,
                    TituloLibro = $"Libro ID: {actual.LibroID}", // Aquí podrías integrar con tu lista de libros
                    NombreUsuario = actual.NombreUsuario,
                    Prioridad = $"{posicion}° - {ObtenerTextoPrioridad(actual.Prioridad)}",
                    TipoUsuario = actual.TipoUsuario,
                    FechaSolicitud = actual.FechaSolicitud,
                    TiempoEspera = tiempoEsperado,
                });
                actual = actual.Siguiente;
                posicion++;
            }
            return reservas;
        }

        private string ObtenerTextoPrioridad(TipoPrioridad prioridad)
        {
            switch (prioridad)
            {
                case TipoPrioridad.Alta:
                    return "Alta";
                case TipoPrioridad.Media:
                    return "Media";
                case TipoPrioridad.Baja:
                    return "Baja";
                default:
                    return "Desconocida";
            }
        }

        //verifica si la cola esta vacia:
        public bool EstaVacia()
        {
            return primero == null;
        }
        //cuenta total de reservas:
        public int NumReservas()
        {
            int contador = 0;
            Reserva actual = primero;

            while (actual != null)
            {
                contador++;
                actual = actual.Siguiente;
            }
            return contador;
        }
        //cuenta reservas por prioridad:
        public Dictionary<TipoPrioridad, int> ReservasPrioridad()
        {
            Dictionary<TipoPrioridad, int> contador = new Dictionary<TipoPrioridad, int>
            {
                { TipoPrioridad.Alta, 0 },
                { TipoPrioridad.Media, 0 },
                { TipoPrioridad.Baja, 0 }
            };

            Reserva actual = primero;
            while (actual != null)
            {
                contador[actual.Prioridad]++;
                actual = actual.Siguiente;
            }

            return contador;
        }

        //guarda las reservas en un archivo:
        public void GuardarEnArchivo()
        {
            using (StreamWriter sw = new StreamWriter(rutaArchivo, false))
            {
                Reserva actual = primero;
                while (actual != null)
                {
                    sw.WriteLine($"{actual.ID}|{actual.LibroID}|{actual.NombreUsuario}" +
                        $"|{(int)actual.Prioridad}|" +
                        $"{actual.TipoUsuario}|{actual.FechaSolicitud:yyyy-MM-dd HH-dd HH:mm:ss}");

                    actual = actual.Siguiente;
                }
            }
        }

        //carga reservas desde el archivo:
        public void CargarDesdeArchivo()
        {
            if (File.Exists(rutaArchivo))
            {
                primero = null;
                ultimoID = 0;

                foreach (string linea in File.ReadAllLines(rutaArchivo))
                {
                    string[] datos = linea.Split('|');
                    if (datos.Length == 6)
                    {
                        int id = int.Parse(datos[0]);
                        int libroID = int.Parse(datos[1]);
                        string nombreUsuario = datos[2];
                        TipoPrioridad prioridad = (TipoPrioridad)int.Parse(datos[3]);
                        string tipoUsuario = datos[4];
                        DateTime fechaSolicitud = DateTime.Parse(datos[5]);

                        //crea la reserva con la fecha original
                        Reserva nuevaReserva = new Reserva(id, libroID, nombreUsuario, prioridad,
                            tipoUsuario, fechaSolicitud);

                        InsertarEnOrden(nuevaReserva);

                        if (id > ultimoID)
                        {
                            ultimoID = id;
                        }
                    }
                }
            }
        }

        //metodo para insertar una reserva manteniendo el orden:
        private void InsertarEnOrden(Reserva nuevaReserva)
        {
            if (primero == null || nuevaReserva.Prioridad < primero.Prioridad ||
                (nuevaReserva.Prioridad == primero.Prioridad && nuevaReserva.FechaSolicitud <= primero.FechaSolicitud))
            {
                nuevaReserva.Siguiente = primero;
                primero = nuevaReserva;
                return;
            }

            Reserva actual = primero;
            while (actual.Siguiente != null)
            {
                if (actual.Siguiente.Prioridad > nuevaReserva.Prioridad ||
                    (actual.Siguiente.Prioridad == primero.Prioridad && nuevaReserva.FechaSolicitud <= primero.FechaSolicitud))
                {
                    nuevaReserva.Siguiente = actual.Siguiente;
                    actual.Siguiente = nuevaReserva;
                    return;
                }
                actual = actual.Siguiente;
            }
            actual.Siguiente = nuevaReserva;
        }

    } //FIN DE LA CLASE, NO TOCAR
}

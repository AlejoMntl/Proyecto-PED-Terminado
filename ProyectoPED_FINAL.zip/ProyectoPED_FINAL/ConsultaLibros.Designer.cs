﻿namespace ProyectoPED_1
{
    partial class ConsultaLibros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
			this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
			this.BtnCargarLibros = new MetroFramework.Controls.MetroButton();
			this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
			this.metroButton2 = new MetroFramework.Controls.MetroButton();
			this.metroButton3 = new MetroFramework.Controls.MetroButton();
			this.txtBuscaAño = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
			this.btnBuscaID = new MetroFramework.Controls.MetroButton();
			this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
			this.txtBuscaAutor = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
			this.txtBuscaID = new MetroFramework.Controls.MetroTextBox();
			this.DGVBuscarLibro = new MetroFramework.Controls.MetroGrid();
			this.label8 = new System.Windows.Forms.Label();
			this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
			this.DGVEliminarLibro = new MetroFramework.Controls.MetroGrid();
			this.BtnCargarLibrosE = new MetroFramework.Controls.MetroButton();
			this.BntEliminarAño = new MetroFramework.Controls.MetroButton();
			this.BtnEliminaAutor = new MetroFramework.Controls.MetroButton();
			this.txtEliminaAño = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
			this.BtnEliminaID = new MetroFramework.Controls.MetroButton();
			this.txtEliminaAutor = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
			this.txtEliminaID = new MetroFramework.Controls.MetroTextBox();
			this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
			this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
			this.btnRegresar = new MetroFramework.Controls.MetroButton();
			this.metroTabControl1.SuspendLayout();
			this.metroTabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGVBuscarLibro)).BeginInit();
			this.metroTabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGVEliminarLibro)).BeginInit();
			this.SuspendLayout();
			// 
			// metroTabControl1
			// 
			this.metroTabControl1.Controls.Add(this.metroTabPage1);
			this.metroTabControl1.Controls.Add(this.metroTabPage2);
			this.metroTabControl1.Location = new System.Drawing.Point(18, 62);
			this.metroTabControl1.Name = "metroTabControl1";
			this.metroTabControl1.SelectedIndex = 0;
			this.metroTabControl1.Size = new System.Drawing.Size(809, 407);
			this.metroTabControl1.TabIndex = 12;
			this.metroTabControl1.UseSelectable = true;
			// 
			// metroTabPage1
			// 
			this.metroTabPage1.Controls.Add(this.BtnCargarLibros);
			this.metroTabPage1.Controls.Add(this.metroLabel4);
			this.metroTabPage1.Controls.Add(this.metroButton2);
			this.metroTabPage1.Controls.Add(this.metroButton3);
			this.metroTabPage1.Controls.Add(this.txtBuscaAño);
			this.metroTabPage1.Controls.Add(this.metroLabel2);
			this.metroTabPage1.Controls.Add(this.btnBuscaID);
			this.metroTabPage1.Controls.Add(this.metroLabel3);
			this.metroTabPage1.Controls.Add(this.txtBuscaAutor);
			this.metroTabPage1.Controls.Add(this.metroLabel1);
			this.metroTabPage1.Controls.Add(this.txtBuscaID);
			this.metroTabPage1.Controls.Add(this.DGVBuscarLibro);
			this.metroTabPage1.Controls.Add(this.label8);
			this.metroTabPage1.HorizontalScrollbarBarColor = true;
			this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
			this.metroTabPage1.HorizontalScrollbarSize = 10;
			this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
			this.metroTabPage1.Name = "metroTabPage1";
			this.metroTabPage1.Size = new System.Drawing.Size(801, 365);
			this.metroTabPage1.TabIndex = 0;
			this.metroTabPage1.Text = "BUSQUEDA";
			this.metroTabPage1.VerticalScrollbarBarColor = true;
			this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
			this.metroTabPage1.VerticalScrollbarSize = 10;
			// 
			// BtnCargarLibros
			// 
			this.BtnCargarLibros.BackColor = System.Drawing.SystemColors.MenuHighlight;
			this.BtnCargarLibros.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.BtnCargarLibros.ForeColor = System.Drawing.SystemColors.Control;
			this.BtnCargarLibros.Location = new System.Drawing.Point(234, 8);
			this.BtnCargarLibros.Name = "BtnCargarLibros";
			this.BtnCargarLibros.Size = new System.Drawing.Size(165, 38);
			this.BtnCargarLibros.TabIndex = 30;
			this.BtnCargarLibros.Text = "CARGAR LIBROS";
			this.BtnCargarLibros.UseCustomBackColor = true;
			this.BtnCargarLibros.UseCustomForeColor = true;
			this.BtnCargarLibros.UseMnemonic = false;
			this.BtnCargarLibros.UseSelectable = true;
			this.BtnCargarLibros.UseStyleColors = true;
			this.BtnCargarLibros.Click += new System.EventHandler(this.BtnCargarLibros_Click_1);
			// 
			// metroLabel4
			// 
			this.metroLabel4.AutoSize = true;
			this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel4.Location = new System.Drawing.Point(3, 21);
			this.metroLabel4.Name = "metroLabel4";
			this.metroLabel4.Size = new System.Drawing.Size(221, 25);
			this.metroLabel4.TabIndex = 34;
			this.metroLabel4.Text = "GESTION DE BUSQUEDA";
			this.metroLabel4.UseStyleColors = true;
			// 
			// metroButton2
			// 
			this.metroButton2.BackColor = System.Drawing.Color.Teal;
			this.metroButton2.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.metroButton2.ForeColor = System.Drawing.SystemColors.Control;
			this.metroButton2.Location = new System.Drawing.Point(25, 321);
			this.metroButton2.Name = "metroButton2";
			this.metroButton2.Size = new System.Drawing.Size(165, 38);
			this.metroButton2.TabIndex = 32;
			this.metroButton2.Text = "BUSCAR AÑO";
			this.metroButton2.UseCustomBackColor = true;
			this.metroButton2.UseCustomForeColor = true;
			this.metroButton2.UseMnemonic = false;
			this.metroButton2.UseSelectable = true;
			this.metroButton2.UseStyleColors = true;
			this.metroButton2.Click += new System.EventHandler(this.btnBuscaAño_Click);
			// 
			// metroButton3
			// 
			this.metroButton3.BackColor = System.Drawing.Color.LightSeaGreen;
			this.metroButton3.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.metroButton3.ForeColor = System.Drawing.SystemColors.Control;
			this.metroButton3.Location = new System.Drawing.Point(25, 277);
			this.metroButton3.Name = "metroButton3";
			this.metroButton3.Size = new System.Drawing.Size(165, 38);
			this.metroButton3.TabIndex = 33;
			this.metroButton3.Text = "BUSCAR AUTOR";
			this.metroButton3.UseCustomBackColor = true;
			this.metroButton3.UseCustomForeColor = true;
			this.metroButton3.UseMnemonic = false;
			this.metroButton3.UseSelectable = true;
			this.metroButton3.UseStyleColors = true;
			this.metroButton3.Click += new System.EventHandler(this.btnBuscaAutor_Click);
			// 
			// txtBuscaAño
			// 
			// 
			// 
			// 
			this.txtBuscaAño.CustomButton.Image = null;
			this.txtBuscaAño.CustomButton.Location = new System.Drawing.Point(93, 2);
			this.txtBuscaAño.CustomButton.Name = "";
			this.txtBuscaAño.CustomButton.Size = new System.Drawing.Size(19, 19);
			this.txtBuscaAño.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtBuscaAño.CustomButton.TabIndex = 1;
			this.txtBuscaAño.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtBuscaAño.CustomButton.UseSelectable = true;
			this.txtBuscaAño.CustomButton.Visible = false;
			this.txtBuscaAño.Lines = new string[0];
			this.txtBuscaAño.Location = new System.Drawing.Point(104, 190);
			this.txtBuscaAño.MaxLength = 32767;
			this.txtBuscaAño.Name = "txtBuscaAño";
			this.txtBuscaAño.PasswordChar = '\0';
			this.txtBuscaAño.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtBuscaAño.SelectedText = "";
			this.txtBuscaAño.SelectionLength = 0;
			this.txtBuscaAño.SelectionStart = 0;
			this.txtBuscaAño.ShortcutsEnabled = true;
			this.txtBuscaAño.Size = new System.Drawing.Size(115, 24);
			this.txtBuscaAño.TabIndex = 29;
			this.txtBuscaAño.UseSelectable = true;
			this.txtBuscaAño.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtBuscaAño.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel2
			// 
			this.metroLabel2.AutoSize = true;
			this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel2.Location = new System.Drawing.Point(0, 129);
			this.metroLabel2.Name = "metroLabel2";
			this.metroLabel2.Size = new System.Drawing.Size(74, 25);
			this.metroLabel2.TabIndex = 27;
			this.metroLabel2.Text = "AUTOR";
			this.metroLabel2.UseStyleColors = true;
			// 
			// btnBuscaID
			// 
			this.btnBuscaID.BackColor = System.Drawing.Color.DodgerBlue;
			this.btnBuscaID.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.btnBuscaID.ForeColor = System.Drawing.SystemColors.Control;
			this.btnBuscaID.Location = new System.Drawing.Point(25, 233);
			this.btnBuscaID.Name = "btnBuscaID";
			this.btnBuscaID.Size = new System.Drawing.Size(165, 38);
			this.btnBuscaID.TabIndex = 31;
			this.btnBuscaID.Text = "BUSCAR ID";
			this.btnBuscaID.UseCustomBackColor = true;
			this.btnBuscaID.UseCustomForeColor = true;
			this.btnBuscaID.UseMnemonic = false;
			this.btnBuscaID.UseSelectable = true;
			this.btnBuscaID.UseStyleColors = true;
			this.btnBuscaID.Click += new System.EventHandler(this.btnBuscaID_Click);
			// 
			// metroLabel3
			// 
			this.metroLabel3.AutoSize = true;
			this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel3.Location = new System.Drawing.Point(-4, 179);
			this.metroLabel3.Name = "metroLabel3";
			this.metroLabel3.Size = new System.Drawing.Size(102, 76);
			this.metroLabel3.TabIndex = 28;
			this.metroLabel3.Text = "AÑO DE\r\nPUBLICACION\r\n\r\n";
			this.metroLabel3.UseStyleColors = true;
			// 
			// txtBuscaAutor
			// 
			// 
			// 
			// 
			this.txtBuscaAutor.CustomButton.Image = null;
			this.txtBuscaAutor.CustomButton.Location = new System.Drawing.Point(117, 2);
			this.txtBuscaAutor.CustomButton.Name = "";
			this.txtBuscaAutor.CustomButton.Size = new System.Drawing.Size(19, 19);
			this.txtBuscaAutor.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtBuscaAutor.CustomButton.TabIndex = 1;
			this.txtBuscaAutor.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtBuscaAutor.CustomButton.UseSelectable = true;
			this.txtBuscaAutor.CustomButton.Visible = false;
			this.txtBuscaAutor.Lines = new string[0];
			this.txtBuscaAutor.Location = new System.Drawing.Point(80, 130);
			this.txtBuscaAutor.MaxLength = 32767;
			this.txtBuscaAutor.Name = "txtBuscaAutor";
			this.txtBuscaAutor.PasswordChar = '\0';
			this.txtBuscaAutor.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtBuscaAutor.SelectedText = "";
			this.txtBuscaAutor.SelectionLength = 0;
			this.txtBuscaAutor.SelectionStart = 0;
			this.txtBuscaAutor.ShortcutsEnabled = true;
			this.txtBuscaAutor.Size = new System.Drawing.Size(139, 24);
			this.txtBuscaAutor.TabIndex = 25;
			this.txtBuscaAutor.UseSelectable = true;
			this.txtBuscaAutor.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtBuscaAutor.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel1
			// 
			this.metroLabel1.AutoSize = true;
			this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel1.Location = new System.Drawing.Point(8, 64);
			this.metroLabel1.Name = "metroLabel1";
			this.metroLabel1.Size = new System.Drawing.Size(31, 25);
			this.metroLabel1.TabIndex = 26;
			this.metroLabel1.Text = "ID";
			this.metroLabel1.UseStyleColors = true;
			// 
			// txtBuscaID
			// 
			// 
			// 
			// 
			this.txtBuscaID.CustomButton.Image = null;
			this.txtBuscaID.CustomButton.Location = new System.Drawing.Point(115, 2);
			this.txtBuscaID.CustomButton.Name = "";
			this.txtBuscaID.CustomButton.Size = new System.Drawing.Size(21, 21);
			this.txtBuscaID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtBuscaID.CustomButton.TabIndex = 1;
			this.txtBuscaID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtBuscaID.CustomButton.UseSelectable = true;
			this.txtBuscaID.CustomButton.Visible = false;
			this.txtBuscaID.Lines = new string[0];
			this.txtBuscaID.Location = new System.Drawing.Point(80, 64);
			this.txtBuscaID.MaxLength = 32767;
			this.txtBuscaID.Name = "txtBuscaID";
			this.txtBuscaID.PasswordChar = '\0';
			this.txtBuscaID.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtBuscaID.SelectedText = "";
			this.txtBuscaID.SelectionLength = 0;
			this.txtBuscaID.SelectionStart = 0;
			this.txtBuscaID.ShortcutsEnabled = true;
			this.txtBuscaID.Size = new System.Drawing.Size(139, 26);
			this.txtBuscaID.TabIndex = 24;
			this.txtBuscaID.UseSelectable = true;
			this.txtBuscaID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtBuscaID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// DGVBuscarLibro
			// 
			this.DGVBuscarLibro.AllowUserToResizeRows = false;
			this.DGVBuscarLibro.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			this.DGVBuscarLibro.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.DGVBuscarLibro.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DGVBuscarLibro.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
			this.DGVBuscarLibro.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
			this.DGVBuscarLibro.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVBuscarLibro.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.DGVBuscarLibro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.DGVBuscarLibro.DefaultCellStyle = dataGridViewCellStyle2;
			this.DGVBuscarLibro.EnableHeadersVisualStyles = false;
			this.DGVBuscarLibro.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.DGVBuscarLibro.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.DGVBuscarLibro.Location = new System.Drawing.Point(234, 52);
			this.DGVBuscarLibro.Name = "DGVBuscarLibro";
			this.DGVBuscarLibro.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVBuscarLibro.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.DGVBuscarLibro.RowHeadersWidth = 51;
			this.DGVBuscarLibro.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.DGVBuscarLibro.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DGVBuscarLibro.Size = new System.Drawing.Size(550, 317);
			this.DGVBuscarLibro.TabIndex = 23;
			this.DGVBuscarLibro.UseCustomBackColor = true;
			this.DGVBuscarLibro.UseCustomForeColor = true;
			this.DGVBuscarLibro.UseStyleColors = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(3, 16);
			this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(0, 24);
			this.label8.TabIndex = 18;
			// 
			// metroTabPage2
			// 
			this.metroTabPage2.Controls.Add(this.DGVEliminarLibro);
			this.metroTabPage2.Controls.Add(this.BtnCargarLibrosE);
			this.metroTabPage2.Controls.Add(this.BntEliminarAño);
			this.metroTabPage2.Controls.Add(this.BtnEliminaAutor);
			this.metroTabPage2.Controls.Add(this.txtEliminaAño);
			this.metroTabPage2.Controls.Add(this.metroLabel6);
			this.metroTabPage2.Controls.Add(this.BtnEliminaID);
			this.metroTabPage2.Controls.Add(this.txtEliminaAutor);
			this.metroTabPage2.Controls.Add(this.metroLabel8);
			this.metroTabPage2.Controls.Add(this.txtEliminaID);
			this.metroTabPage2.Controls.Add(this.metroLabel5);
			this.metroTabPage2.Controls.Add(this.metroLabel7);
			this.metroTabPage2.HorizontalScrollbarBarColor = true;
			this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
			this.metroTabPage2.HorizontalScrollbarSize = 10;
			this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
			this.metroTabPage2.Name = "metroTabPage2";
			this.metroTabPage2.Size = new System.Drawing.Size(801, 365);
			this.metroTabPage2.TabIndex = 1;
			this.metroTabPage2.Text = "ELIMINACION";
			this.metroTabPage2.VerticalScrollbarBarColor = true;
			this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
			this.metroTabPage2.VerticalScrollbarSize = 10;
			// 
			// DGVEliminarLibro
			// 
			this.DGVEliminarLibro.AllowUserToResizeRows = false;
			this.DGVEliminarLibro.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			this.DGVEliminarLibro.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.DGVEliminarLibro.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DGVEliminarLibro.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
			this.DGVEliminarLibro.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
			this.DGVEliminarLibro.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVEliminarLibro.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
			this.DGVEliminarLibro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.MenuHighlight;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.DGVEliminarLibro.DefaultCellStyle = dataGridViewCellStyle5;
			this.DGVEliminarLibro.EnableHeadersVisualStyles = false;
			this.DGVEliminarLibro.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.DGVEliminarLibro.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.DGVEliminarLibro.Location = new System.Drawing.Point(234, 52);
			this.DGVEliminarLibro.Name = "DGVEliminarLibro";
			this.DGVEliminarLibro.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
			dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
			dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
			dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.DGVEliminarLibro.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
			this.DGVEliminarLibro.RowHeadersWidth = 51;
			this.DGVEliminarLibro.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.DGVEliminarLibro.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DGVEliminarLibro.Size = new System.Drawing.Size(564, 317);
			this.DGVEliminarLibro.TabIndex = 46;
			this.DGVEliminarLibro.UseCustomBackColor = true;
			this.DGVEliminarLibro.UseCustomForeColor = true;
			this.DGVEliminarLibro.UseStyleColors = true;
			// 
			// BtnCargarLibrosE
			// 
			this.BtnCargarLibrosE.BackColor = System.Drawing.SystemColors.MenuHighlight;
			this.BtnCargarLibrosE.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.BtnCargarLibrosE.ForeColor = System.Drawing.SystemColors.Control;
			this.BtnCargarLibrosE.Location = new System.Drawing.Point(234, 8);
			this.BtnCargarLibrosE.Name = "BtnCargarLibrosE";
			this.BtnCargarLibrosE.Size = new System.Drawing.Size(165, 38);
			this.BtnCargarLibrosE.TabIndex = 45;
			this.BtnCargarLibrosE.Text = "CARGAR LIBROS";
			this.BtnCargarLibrosE.UseCustomBackColor = true;
			this.BtnCargarLibrosE.UseCustomForeColor = true;
			this.BtnCargarLibrosE.UseMnemonic = false;
			this.BtnCargarLibrosE.UseSelectable = true;
			this.BtnCargarLibrosE.UseStyleColors = true;
			this.BtnCargarLibrosE.Click += new System.EventHandler(this.BtnCargarLibros_Click_1);
			// 
			// BntEliminarAño
			// 
			this.BntEliminarAño.BackColor = System.Drawing.Color.IndianRed;
			this.BntEliminarAño.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.BntEliminarAño.ForeColor = System.Drawing.SystemColors.Control;
			this.BntEliminarAño.Location = new System.Drawing.Point(27, 321);
			this.BntEliminarAño.Name = "BntEliminarAño";
			this.BntEliminarAño.Size = new System.Drawing.Size(165, 37);
			this.BntEliminarAño.TabIndex = 43;
			this.BntEliminarAño.Text = "ELIMINAR POR AÑO";
			this.BntEliminarAño.UseCustomBackColor = true;
			this.BntEliminarAño.UseCustomForeColor = true;
			this.BntEliminarAño.UseMnemonic = false;
			this.BntEliminarAño.UseSelectable = true;
			this.BntEliminarAño.UseStyleColors = true;
			this.BntEliminarAño.Click += new System.EventHandler(this.BntEliminarAño_Click);
			// 
			// BtnEliminaAutor
			// 
			this.BtnEliminaAutor.BackColor = System.Drawing.Color.Firebrick;
			this.BtnEliminaAutor.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.BtnEliminaAutor.ForeColor = System.Drawing.SystemColors.Control;
			this.BtnEliminaAutor.Location = new System.Drawing.Point(27, 271);
			this.BtnEliminaAutor.Name = "BtnEliminaAutor";
			this.BtnEliminaAutor.Size = new System.Drawing.Size(165, 44);
			this.BtnEliminaAutor.TabIndex = 44;
			this.BtnEliminaAutor.Text = "ELIMINAR \r\nPOR AUTOR";
			this.BtnEliminaAutor.UseCustomBackColor = true;
			this.BtnEliminaAutor.UseCustomForeColor = true;
			this.BtnEliminaAutor.UseMnemonic = false;
			this.BtnEliminaAutor.UseSelectable = true;
			this.BtnEliminaAutor.UseStyleColors = true;
			this.BtnEliminaAutor.Click += new System.EventHandler(this.BtnEliminaAutor_Click);
			// 
			// txtEliminaAño
			// 
			// 
			// 
			// 
			this.txtEliminaAño.CustomButton.Image = null;
			this.txtEliminaAño.CustomButton.Location = new System.Drawing.Point(93, 2);
			this.txtEliminaAño.CustomButton.Name = "";
			this.txtEliminaAño.CustomButton.Size = new System.Drawing.Size(19, 19);
			this.txtEliminaAño.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtEliminaAño.CustomButton.TabIndex = 1;
			this.txtEliminaAño.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtEliminaAño.CustomButton.UseSelectable = true;
			this.txtEliminaAño.CustomButton.Visible = false;
			this.txtEliminaAño.Lines = new string[0];
			this.txtEliminaAño.Location = new System.Drawing.Point(104, 172);
			this.txtEliminaAño.MaxLength = 32767;
			this.txtEliminaAño.Name = "txtEliminaAño";
			this.txtEliminaAño.PasswordChar = '\0';
			this.txtEliminaAño.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtEliminaAño.SelectedText = "";
			this.txtEliminaAño.SelectionLength = 0;
			this.txtEliminaAño.SelectionStart = 0;
			this.txtEliminaAño.ShortcutsEnabled = true;
			this.txtEliminaAño.Size = new System.Drawing.Size(115, 24);
			this.txtEliminaAño.TabIndex = 41;
			this.txtEliminaAño.UseSelectable = true;
			this.txtEliminaAño.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtEliminaAño.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel6
			// 
			this.metroLabel6.AutoSize = true;
			this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel6.Location = new System.Drawing.Point(-4, 120);
			this.metroLabel6.Name = "metroLabel6";
			this.metroLabel6.Size = new System.Drawing.Size(74, 25);
			this.metroLabel6.TabIndex = 39;
			this.metroLabel6.Text = "AUTOR";
			this.metroLabel6.UseStyleColors = true;
			// 
			// BtnEliminaID
			// 
			this.BtnEliminaID.BackColor = System.Drawing.Color.Maroon;
			this.BtnEliminaID.FontSize = MetroFramework.MetroButtonSize.Tall;
			this.BtnEliminaID.ForeColor = System.Drawing.SystemColors.Control;
			this.BtnEliminaID.Location = new System.Drawing.Point(27, 228);
			this.BtnEliminaID.Name = "BtnEliminaID";
			this.BtnEliminaID.Size = new System.Drawing.Size(165, 37);
			this.BtnEliminaID.TabIndex = 42;
			this.BtnEliminaID.Text = "ELIMINAR POR ID";
			this.BtnEliminaID.UseCustomBackColor = true;
			this.BtnEliminaID.UseCustomForeColor = true;
			this.BtnEliminaID.UseMnemonic = false;
			this.BtnEliminaID.UseSelectable = true;
			this.BtnEliminaID.UseStyleColors = true;
			this.BtnEliminaID.Click += new System.EventHandler(this.BtnEliminaID_Click);
			// 
			// txtEliminaAutor
			// 
			// 
			// 
			// 
			this.txtEliminaAutor.CustomButton.Image = null;
			this.txtEliminaAutor.CustomButton.Location = new System.Drawing.Point(117, 2);
			this.txtEliminaAutor.CustomButton.Name = "";
			this.txtEliminaAutor.CustomButton.Size = new System.Drawing.Size(19, 19);
			this.txtEliminaAutor.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtEliminaAutor.CustomButton.TabIndex = 1;
			this.txtEliminaAutor.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtEliminaAutor.CustomButton.UseSelectable = true;
			this.txtEliminaAutor.CustomButton.Visible = false;
			this.txtEliminaAutor.Lines = new string[0];
			this.txtEliminaAutor.Location = new System.Drawing.Point(82, 120);
			this.txtEliminaAutor.MaxLength = 32767;
			this.txtEliminaAutor.Name = "txtEliminaAutor";
			this.txtEliminaAutor.PasswordChar = '\0';
			this.txtEliminaAutor.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtEliminaAutor.SelectedText = "";
			this.txtEliminaAutor.SelectionLength = 0;
			this.txtEliminaAutor.SelectionStart = 0;
			this.txtEliminaAutor.ShortcutsEnabled = true;
			this.txtEliminaAutor.Size = new System.Drawing.Size(139, 24);
			this.txtEliminaAutor.TabIndex = 37;
			this.txtEliminaAutor.UseSelectable = true;
			this.txtEliminaAutor.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtEliminaAutor.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel8
			// 
			this.metroLabel8.AutoSize = true;
			this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel8.Location = new System.Drawing.Point(0, 63);
			this.metroLabel8.Name = "metroLabel8";
			this.metroLabel8.Size = new System.Drawing.Size(31, 25);
			this.metroLabel8.TabIndex = 38;
			this.metroLabel8.Text = "ID";
			this.metroLabel8.UseStyleColors = true;
			// 
			// txtEliminaID
			// 
			// 
			// 
			// 
			this.txtEliminaID.CustomButton.Image = null;
			this.txtEliminaID.CustomButton.Location = new System.Drawing.Point(115, 2);
			this.txtEliminaID.CustomButton.Name = "";
			this.txtEliminaID.CustomButton.Size = new System.Drawing.Size(21, 21);
			this.txtEliminaID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
			this.txtEliminaID.CustomButton.TabIndex = 1;
			this.txtEliminaID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
			this.txtEliminaID.CustomButton.UseSelectable = true;
			this.txtEliminaID.CustomButton.Visible = false;
			this.txtEliminaID.Lines = new string[0];
			this.txtEliminaID.Location = new System.Drawing.Point(77, 62);
			this.txtEliminaID.MaxLength = 32767;
			this.txtEliminaID.Name = "txtEliminaID";
			this.txtEliminaID.PasswordChar = '\0';
			this.txtEliminaID.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.txtEliminaID.SelectedText = "";
			this.txtEliminaID.SelectionLength = 0;
			this.txtEliminaID.SelectionStart = 0;
			this.txtEliminaID.ShortcutsEnabled = true;
			this.txtEliminaID.Size = new System.Drawing.Size(139, 26);
			this.txtEliminaID.TabIndex = 36;
			this.txtEliminaID.UseSelectable = true;
			this.txtEliminaID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
			this.txtEliminaID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
			// 
			// metroLabel5
			// 
			this.metroLabel5.AutoSize = true;
			this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
			this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel5.Location = new System.Drawing.Point(0, 21);
			this.metroLabel5.Name = "metroLabel5";
			this.metroLabel5.Size = new System.Drawing.Size(221, 25);
			this.metroLabel5.TabIndex = 35;
			this.metroLabel5.Text = "GESTION DE BUSQUEDA";
			this.metroLabel5.UseStyleColors = true;
			this.metroLabel5.Click += new System.EventHandler(this.metroLabel5_Click);
			// 
			// metroLabel7
			// 
			this.metroLabel7.AutoSize = true;
			this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
			this.metroLabel7.Location = new System.Drawing.Point(-4, 172);
			this.metroLabel7.Name = "metroLabel7";
			this.metroLabel7.Size = new System.Drawing.Size(102, 76);
			this.metroLabel7.TabIndex = 40;
			this.metroLabel7.Text = "AÑO DE\r\nPUBLICACION\r\n\r\n";
			this.metroLabel7.UseStyleColors = true;
			// 
			// btnRegresar
			// 
			this.btnRegresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
			this.btnRegresar.FontSize = MetroFramework.MetroButtonSize.Medium;
			this.btnRegresar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.btnRegresar.Location = new System.Drawing.Point(681, 475);
			this.btnRegresar.Name = "btnRegresar";
			this.btnRegresar.Size = new System.Drawing.Size(125, 37);
			this.btnRegresar.TabIndex = 31;
			this.btnRegresar.Text = "SALIR";
			this.btnRegresar.UseCustomBackColor = true;
			this.btnRegresar.UseCustomForeColor = true;
			this.btnRegresar.UseSelectable = true;
			this.btnRegresar.UseStyleColors = true;
			this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
			// 
			// ConsultaLibros
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(836, 534);
			this.Controls.Add(this.btnRegresar);
			this.Controls.Add(this.metroTabControl1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "ConsultaLibros";
			this.Padding = new System.Windows.Forms.Padding(15, 60, 15, 16);
			this.Text = "ConsultaLibros";
			this.Load += new System.EventHandler(this.ConsultaLibros_Load);
			this.metroTabControl1.ResumeLayout(false);
			this.metroTabPage1.ResumeLayout(false);
			this.metroTabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGVBuscarLibro)).EndInit();
			this.metroTabPage2.ResumeLayout(false);
			this.metroTabPage2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGVEliminarLibro)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion
		private MetroFramework.Controls.MetroTabControl metroTabControl1;
		private MetroFramework.Controls.MetroTabPage metroTabPage1;
		private System.Windows.Forms.Label label8;
		private MetroFramework.Controls.MetroTabPage metroTabPage2;
		private MetroFramework.Controls.MetroGrid DGVBuscarLibro;
		private MetroFramework.Controls.MetroTextBox txtBuscaAño;
		private MetroFramework.Controls.MetroLabel metroLabel2;
		private MetroFramework.Controls.MetroLabel metroLabel3;
		private MetroFramework.Controls.MetroTextBox txtBuscaAutor;
		private MetroFramework.Controls.MetroLabel metroLabel1;
		private MetroFramework.Controls.MetroTextBox txtBuscaID;
		private MetroFramework.Controls.MetroButton metroButton2;
		private MetroFramework.Controls.MetroButton metroButton3;
		private MetroFramework.Controls.MetroButton btnBuscaID;
		private MetroFramework.Controls.MetroButton BtnCargarLibros;
		private MetroFramework.Controls.MetroButton btnRegresar;
		private MetroFramework.Controls.MetroLabel metroLabel4;
		private MetroFramework.Controls.MetroButton BntEliminarAño;
		private MetroFramework.Controls.MetroButton BtnEliminaAutor;
		private MetroFramework.Controls.MetroTextBox txtEliminaAño;
		private MetroFramework.Controls.MetroLabel metroLabel6;
		private MetroFramework.Controls.MetroButton BtnEliminaID;
		private MetroFramework.Controls.MetroLabel metroLabel7;
		private MetroFramework.Controls.MetroTextBox txtEliminaAutor;
		private MetroFramework.Controls.MetroLabel metroLabel8;
		private MetroFramework.Controls.MetroTextBox txtEliminaID;
		private MetroFramework.Controls.MetroLabel metroLabel5;
		private MetroFramework.Controls.MetroGrid DGVEliminarLibro;
		private MetroFramework.Controls.MetroButton BtnCargarLibrosE;
	}
}
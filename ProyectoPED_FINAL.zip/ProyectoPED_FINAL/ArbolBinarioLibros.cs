﻿using System.Collections.Generic;
using System.Text;

namespace ProyectoPED_1
{
    //clase utilizada para la gestion eficiente de la busqueda y eliminacion de los libros:
    internal class ArbolBinarioLibros
    {
        private NodoArbol raiz; //referencia al Nodo
        private ArbolBinarioLibros _arbol;
        public ArbolBinarioLibros()
        {
            raiz = null;
        }
        public ArbolBinarioLibros(ArbolBinarioLibros arbol)
        {
            _arbol = arbol;
        }

        public void InsertarID(Libro libro)
        {
            raiz = InsertarNodoID(raiz, libro);
        }

        private NodoArbol InsertarNodoID(NodoArbol nodo, Libro libro)
        {
            if (nodo == null)
                return new NodoArbol(libro);

            if (libro.ID < nodo.Valor.ID)
                nodo.Izquierdo = InsertarNodoID(nodo.Izquierdo, libro);
            if (libro.ID > nodo.Valor.ID)
                nodo.Derecho = InsertarNodoID(nodo.Derecho, libro);

            return nodo;
        }

        //metodo para buscar un libro por ID:
        public Libro BuscarPorID(int id)
        {
            return BuscarNodoPorID(raiz, id)?.Valor;
        }

        private NodoArbol BuscarNodoPorID(NodoArbol nodo, int id)
        {
            if (nodo == null || nodo.Valor.ID == id)
                return nodo;

            if (id < nodo.Valor.ID)
                return BuscarNodoPorID(nodo.Izquierdo, id);
            else
                return BuscarNodoPorID(nodo.Derecho, id);
        }

        //busca libro por el autor:
        public List<Libro> BuscarAutor(string autor)
        {
            List<Libro> resultado = new List<Libro>();
            BuscarPorAutor(raiz, autor, resultado);
            return resultado;
        }
        private void BuscarPorAutor(NodoArbol nodo, string autor, List<Libro> resultado)
        {
            if (nodo == null)
                return;


            //busqueda en orden (inorden):
            BuscarPorAutor(nodo.Izquierdo, autor, resultado);

            if (nodo.Valor.Autor.ToLower().Contains(autor.ToLower()))
                resultado.Add(nodo.Valor);

            BuscarPorAutor(nodo.Derecho, autor, resultado);
        }

        //buscar libros por año de publicacion:
        public List<Libro> BuscarAño(int año)
        {
            List<Libro> resultado = new List<Libro>();
            BuscarPoraño(raiz, año, resultado);
            return resultado;
        }
        private void BuscarPoraño(NodoArbol nodo, int año, List<Libro> resultado)
        {
            if (nodo == null)
                return;

            BuscarPoraño(nodo.Izquierdo, año, resultado);

            if (nodo.Valor.añoPublicacion == año)
                resultado.Add(nodo.Valor);

            BuscarPoraño(nodo.Derecho, año, resultado);
        }


        //METODOS PARA LA ELIMINACION DE LIBROS:

        public void EliminarID(int id)
        {
            raiz = ELiminarPorID(raiz, id);
        }

        private NodoArbol ELiminarPorID(NodoArbol nodo, int id)
        {
            if (nodo == null) return null;
            //busca el nodo a Eliminar
            if (id < nodo.Valor.ID)
                nodo.Izquierdo = ELiminarPorID(nodo.Izquierdo, id);
            else if (id > nodo.Valor.ID)
                nodo.Derecho = ELiminarPorID(nodo.Derecho, id);
            else
            {
                //en caso que el nodo hoja no tenga hijos
                if (nodo.Izquierdo == null && nodo.Derecho == null)
                    return null;
                //nodo con un solo hijo
                if (nodo.Izquierdo == null)
                    return nodo.Derecho;
                if (nodo.Derecho == null)
                    return nodo.Izquierdo;


                //nood con dos hijos
                //encuentra el sucesor inmediato, o sea, el menor valor en el subarbol derecho
                nodo.Valor = EncontrarMinimo(nodo.Derecho);
                //elimina a ese sucesor
                nodo.Derecho = ELiminarPorID(nodo.Derecho, nodo.Valor.ID);

            }
            return nodo;
        }
        private Libro EncontrarMinimo(NodoArbol nodo)
        {
            Libro min = nodo.Valor;
            while (nodo.Izquierdo != null)
            {
                min = nodo.Izquierdo.Valor;
                nodo = nodo.Izquierdo;

            }
            return min;
        }

        public int EliminarAutor(string autor)
        {
            List<int> Eliminado = new List<int>();
            EncontrarAutor(raiz, autor, Eliminado);

            int contador = 0; //sirve para contar los eliminados
            foreach (int id in Eliminado)
            {
                EliminarID(id);
                contador++;
            }
            return contador;

        }

        private void EncontrarAutor(NodoArbol nodo, string autor, List<int> Eliminado)
        {
            if (nodo == null)
                return;

            EncontrarAutor(nodo.Izquierdo, autor, Eliminado);

            if (nodo.Valor.Autor.ToLower().Contains(autor.ToLower()))
                Eliminado.Add(nodo.Valor.ID);

            EncontrarAutor(nodo.Derecho, autor, Eliminado);
        }

        public int EliminarAño(int año)
        {
            List<int> Eliminado = new List<int>();
            EncontrarAño(raiz, año, Eliminado);

            int contador = 0;
            foreach (int id in Eliminado)
            {
                EliminarID(id);
                contador++;
            }
            return contador;
        }

        private void EncontrarAño(NodoArbol nodo, int año, List<int> eliminado)
        {
            if (nodo == null)
                return;

            EncontrarAño(nodo.Izquierdo, año, eliminado);
            if (nodo.Valor.añoPublicacion == año)
                eliminado.Add(nodo.Valor.ID);

            EncontrarAño(nodo.Derecho, año, eliminado);
        }

        public List<Libro> ObtenerLibros()
        {
            List<Libro> libros = new List<Libro>();
            RecorridoInOrden(raiz, libros);
            return libros;
        }
        private void RecorridoInOrden(NodoArbol nodo, List<Libro> libros)
        {
            if (nodo == null)
                return;

            RecorridoInOrden(nodo.Izquierdo, libros);
            libros.Add(nodo.Valor);
            RecorridoInOrden(nodo.Derecho, libros);

        }

        public void SincronizarConListaEnlazada(ListaEnlazada lista)
        {
            // Reiniciar el árbol
            raiz = null;

            // Obtener todos los libros de la lista enlazada y agregarlos al árbol
            List<LibroDTO> librosDTO = lista.ObtenerLibros();
            foreach (LibroDTO dto in librosDTO)
            {
                Libro libro = new Libro(
                    dto.ID,
                    dto.Autor,
                    dto.Titulo,
                    dto.AñoPublicacion,
                    dto.Disponibilidad
                );
                InsertarID(libro);
            }
        }
        //Prueba para ver el arbol desde el txt 


        private void ObtenerArbolVisual(NodoArbol nodo, int nivel, StringBuilder sb)
        {
            if (nodo == null) return;

            // Subárbol derecho (arriba en la visualización)
            ObtenerArbolVisual(nodo.Derecho, nivel + 1, sb);

            // Sangría según el nivel
            sb.Append(' ', nivel * 4);
            sb.AppendLine($"[{nodo.Valor.ID}] {nodo.Valor.Titulo}");

            // Subárbol izquierdo (abajo en la visualización)
            ObtenerArbolVisual(nodo.Izquierdo, nivel + 1, sb);
        }
        public string ObtenerArbolVisual()
        {
            StringBuilder sb = new StringBuilder();
            ObtenerArbolVisual(raiz, 0, sb);
            return sb.ToString();
        }
        //prueba de busqueda por titulo de libro 

        // Método público para buscar libros por título
        public List<Libro> BuscarPorTitulo(string titulo)
        {
            List<Libro> resultado = new List<Libro>();
            BuscarNodosPorTitulo(raiz, titulo.ToLower(), resultado);
            return resultado;
        }

        // Método privado recursivo para la búsqueda por título
        private void BuscarNodosPorTitulo(NodoArbol nodo, string tituloBuscado, List<Libro> resultado)
        {
            if (nodo == null)
                return;

            // Búsqueda en orden (inorden)
            BuscarNodosPorTitulo(nodo.Izquierdo, tituloBuscado, resultado);

            // Comparamos los títulos
            if (nodo.Valor.Titulo.ToLower().Contains(tituloBuscado))
                resultado.Add(nodo.Valor);

            BuscarNodosPorTitulo(nodo.Derecho, tituloBuscado, resultado);
        }

    }//NO tocar nada a partir de acá
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ProyectoPED_1
{
    public partial class ConsultaLibros : MetroFramework.Forms.MetroForm
    {
        //referencia al Frm de la gestion
        private FrmGestionLibros gestion;

        private ListaEnlazada enlazada;
        private ArbolBinarioLibros arbolLibros;



        public ConsultaLibros(FrmGestionLibros Gestion)
        {
            InitializeComponent();
            gestion = Gestion;
            enlazada = gestion.ObtenerListaEnlazada();
            arbolLibros = new ArbolBinarioLibros();
            ConfigurarDGV();

            // Forzar recarga desde archivo
            enlazada.CargarDesdeArchivo();
            // Construir el árbol con los datos actualizados
            this.arbolLibros = new ArbolBinarioLibros();

            foreach (var libroDTO in enlazada.ObtenerLibros())
            {
                Libro libro = new Libro(
                    libroDTO.ID,
                    libroDTO.Autor,
                    libroDTO.Titulo,
                    libroDTO.AñoPublicacion,
                    libroDTO.Disponibilidad
                );
                arbolLibros.InsertarID(libro);
            }

            MostrarResultado(arbolLibros.ObtenerLibros());
        }

        private void ConfigurarDGV()
        {
            DGVBuscarLibro.AutoGenerateColumns = false;

            DGVBuscarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ID",
                HeaderText = "ID",
                DataPropertyName = "ID",
            });

            DGVBuscarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Titulo",
                HeaderText = "Titulo",
                DataPropertyName = "Titulo",
                Width = 150
            });
            DGVBuscarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Autor",
                HeaderText = "Autor",
                DataPropertyName = "Autor",
                Width = 150
            });

            DGVBuscarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "AñoPublicacion",
                HeaderText = "Año de Publicación",
                DataPropertyName = "AñoPublicacion"
            });

            //para DGV ELIMINAR 
            DGVEliminarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ID",
                HeaderText = "ID",
                DataPropertyName = "ID",
            });

            DGVEliminarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Titulo",
                HeaderText = "Titulo",
                DataPropertyName = "Titulo",
                Width = 150
            });
            DGVEliminarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Autor",
                HeaderText = "Autor",
                DataPropertyName = "Autor",
                Width = 150
            });

            DGVEliminarLibro.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "AñoPublicacion",
                HeaderText = "Año de Publicación",
                DataPropertyName = "AñoPublicacion"
            });


        }


        private void ConsultaLibros_Load(object sender, EventArgs e)
        {
            // arbolLibros.SincronizarConListaEnlazada(enlazada);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtBuscaID_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtBuscaAutor_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtBuscaAño_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBuscaID_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtBuscaID.Text, out int id))
                {
                    MessageBox.Show("Por favor, ingrese un ID válido", "ID inválido",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Libro libro = arbolLibros.BuscarPorID(id);

                if (libro != null)
                {
                    List<Libro> resultado = new List<Libro> { libro };
                    MostrarResultado(resultado);

                    MessageBox.Show("Libro Encontrado", "Exito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    DGVBuscarLibro.DataSource = null;
                    MessageBox.Show($"No se encontró un libro con un ID: {id}", "Libro no encontrado",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar libro: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnBuscaAutor_Click(object sender, EventArgs e)
        {
            try
            {
                string autor = txtBuscaAutor.Text.Trim();

                if (string.IsNullOrEmpty(autor))
                {
                    MessageBox.Show("Por favor, ingrese un autor para buscar", "Autor Vacio",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                List<Libro> librosEncontrados = arbolLibros.BuscarAutor(autor);

                if (librosEncontrados.Count > 0)
                {
                    MostrarResultado(librosEncontrados);
                    MessageBox.Show($"Se encontraron {librosEncontrados.Count} libros del autor {autor}",
                        "Busqueda Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    DGVBuscarLibro.DataSource = null;
                    MessageBox.Show($"No se encontraron libros del autor {autor}", "Busqueda Terminada",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar por el autor {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscaAño_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtBuscaAño.Text, out int año))
                {
                    MessageBox.Show("Por favor, ingrese un año válido", "Año invalido",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                List<Libro> librosEncontrados = arbolLibros.BuscarAño(año);

                if (librosEncontrados.Count > 0)
                {
                    MostrarResultado(librosEncontrados);
                    MessageBox.Show($"Se encontraron {librosEncontrados.Count} libros del año {año}",
                        "Busqueda Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    DGVBuscarLibro.DataSource = null;
                    MessageBox.Show($"No se encontraron libros publicados en el año {año}", "Busqueda Terminada",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar por año: {ex.Message}", "Sin Resultados",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DGVBuscarLibro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Regresando a la Gestion de los Libros", "Aviso",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            gestion.Show();
            this.Close();
        }

        private void MostrarResultado(List<Libro> libros)
        {
            List<LibroDTO> librosDTO = new List<LibroDTO>();

            foreach (Libro libro in libros)
            {
                librosDTO.Add(new LibroDTO
                {
                    ID = libro.ID,
                    Autor = libro.Autor,
                    Titulo = libro.Titulo,
                    AñoPublicacion = libro.añoPublicacion,
                    Disponibilidad = libro.Disponibilidad,
                });

            }

            DGVBuscarLibro.DataSource = null;
            DGVBuscarLibro.DataSource = librosDTO;

            //para DGVELIMINAR 

            DGVEliminarLibro.DataSource = null;
            DGVEliminarLibro.DataSource = librosDTO;
        }

        //Funcion modificada para poder borrar desde el txt
        private void BtnEliminaID_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtEliminaID.Text, out int id))
                {
                    MessageBox.Show("Ingrese un ID válido", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Eliminar de la lista y actualizar TXT
                bool eliminado = enlazada.EliminarLibroTXT(id);

                if (eliminado)
                {
                    //Actualizar árbol
                    arbolLibros.EliminarID(id);

                    //Actualizar vista
                    MostrarResultado(arbolLibros.ObtenerLibros());

                    MessageBox.Show($"Libro ID {id} eliminado correctamente", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No se encontró el libro con el ID especificado", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnEliminaAutor_Click(object sender, EventArgs e)
        {
            try
            {
                string autor = txtEliminaAutor.Text.Trim();

                if (string.IsNullOrEmpty(autor))
                {
                    MessageBox.Show("Por favor, ingrese el nombre de un autor válido", "Autor Vacío",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                List<Libro> librosEliminar = arbolLibros.BuscarAutor(autor);

                if (librosEliminar.Count == 0)
                {
                    MessageBox.Show($"No se encontraron libros del autor '{autor}'", "Sin resultados",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show(
                    $"¿Está seguro de eliminar el libro: {librosEliminar[0].Titulo} del autor '{autor}'?",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirmacion == DialogResult.Yes)
                {
                    // Eliminar de la lista y actualizar TXT
                    bool eliminados = enlazada.EliminarLibrosPorAutorTXT(autor);

                    if (eliminados)
                    {
                        // Eliminar del árbol
                        int cantidad = arbolLibros.EliminarAutor(autor);
                        arbolLibros.SincronizarConListaEnlazada(enlazada);
                        MostrarResultado(arbolLibros.ObtenerLibros());

                        MessageBox.Show($"Se eliminaron {cantidad} libros del autor {autor}",
                            "Eliminación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar libros por autor: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BntEliminarAño_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtEliminaAño.Text, out int año))
                {
                    MessageBox.Show("Por favor, ingrese un año válido", "Año Inválido",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                List<Libro> librosEliminar = arbolLibros.BuscarAño(año);

                if (librosEliminar.Count == 0)
                {
                    MessageBox.Show($"No se encontraron libros del año {año}", "Sin Resultados",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show(
                    $"¿Está seguro de eliminar el libro: {librosEliminar[0].Titulo} del año {año}?",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirmacion == DialogResult.Yes)
                {
                    // Eliminar de la lista y actualizar TXT
                    bool eliminados = enlazada.EliminarLibrosPorAñoTXT(año);

                    if (eliminados)
                    {
                        // Eliminar del árbol
                        int cantidad = arbolLibros.EliminarAño(año);
                        arbolLibros.SincronizarConListaEnlazada(enlazada);
                        MostrarResultado(arbolLibros.ObtenerLibros());

                        MessageBox.Show($"Se eliminaron {cantidad} libros del año {año}", "Eliminación Exitosa",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar libros por año: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void BtnCargarLibros_Click_1(object sender, EventArgs e)
        {
            try
            {
                string ruta = Path.Combine(Application.StartupPath, "libros.txt");

                if (!File.Exists(ruta))
                {
                    MessageBox.Show("No se encontró el archivo libros.txt", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                //Limpiar estructuras existentes SIN crear nuevas instancias
                arbolLibros = new ArbolBinarioLibros(); // Solo reiniciamos el árbol

                //Forzar recarga en la lista existente
                enlazada.CargarDesdeArchivo(); // Esto actualizará la lista con los datos del TXT

                //Reconstruir árbol desde la lista (que ya está sincronizada con el TXT)
                foreach (var libroDTO in enlazada.ObtenerLibros())
                {
                    Libro libro = new Libro(
                        libroDTO.ID,
                        libroDTO.Autor,
                        libroDTO.Titulo,
                        libroDTO.AñoPublicacion,
                        libroDTO.Disponibilidad
                    );
                    arbolLibros.InsertarID(libro);
                }

                // Mostrar resultados
                MostrarResultado(arbolLibros.ObtenerLibros());

                MessageBox.Show($"Libros cargados: {enlazada.ObtenerLibros().Count}", "Éxito",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar TXT: {ex.Message}\nRuta: {Application.StartupPath}\\libros.txt",
                              "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void metroLabel5_Click(object sender, EventArgs e)
        {

        }



        //TENGO DUDA EN ESTE TROZO 
        /*
		private void MostrarArbolEnDGV()
		{
			// Limpiar el DataGridView
			DGVBuscarLibro.Rows.Clear();
			DGVBuscarLibro.Columns.Clear();

			// Configurar para mostrar el árbol
			DataGridViewTextBoxColumn columna = new DataGridViewTextBoxColumn();
			columna.HeaderText = "Árbol Binario de Libros";
			columna.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			DGVBuscarLibro.Columns.Add(columna);

			// Obtener representación del árbol
			string arbolVisual = arbolLibros.ObtenerArbolVisual();
			string[] lineas = arbolVisual.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

			// Agregar cada línea como una fila
			foreach (string linea in lineas)
			{
				DGVBuscarLibro.Rows.Add(linea.Trim());
			}
		}
        */
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ProyectoPED_1
{
    //Sirve para mostrar las reservas en el DGV
    internal class ReservaDTO
    {
        public int ID { get; set; }
        public int LibroID { get; set; }
        public string TituloLibro { get; set; }
        public string NombreUsuario { get; set; }
        public string Prioridad { get; set; }
        public string TipoUsuario { get; set; }
        public DateTime FechaSolicitud { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string TiempoEspera { get; set; }
        public string FechaFormateada => FechaSolicitud.ToString("dd/MM/yyyy HH:mm");
        public string PeriodoReserva =>
            $"{FechaInicio:dd/MM/yyyy} al {FechaFin:dd/MM/yyyy}";

        public string DiasRestantes =>
            (FechaFin - DateTime.Today).Days > 0 ?
            $"{(FechaFin - DateTime.Today).Days} días" :
            "Vencida";

        // Método para crear DTO desde una Reserva
        public static ReservaDTO FromReserva(Reserva reserva, List<LibroDTO> listalibro)
        {
            var libro = listalibro.FirstOrDefault(l => l.ID == reserva.LibroID);
            string tituloLibro = libro != null ? libro.Titulo : $"Libro ID: {reserva.LibroID}";

            TimeSpan tiempoEspera = DateTime.Now - reserva.FechaSolicitud;

            return new ReservaDTO
            {
                ID = reserva.ID,
                LibroID = reserva.LibroID,
                TituloLibro = tituloLibro,
                NombreUsuario = reserva.NombreUsuario,
                TipoUsuario = reserva.TipoUsuario,
                Prioridad = $"{reserva.Prioridad} ({reserva.TipoUsuario})",
                FechaSolicitud = reserva.FechaSolicitud,
                FechaInicio = reserva.FechaInicio,
                FechaFin = reserva.FechaFin,
                TiempoEspera = FormatTiempoEspera(tiempoEspera)
            };
        }

        private static string FormatTiempoEspera(TimeSpan tiempo)
        {
            if (tiempo.TotalDays > 1)
                return $"{(int)tiempo.TotalDays} días";
            if (tiempo.TotalHours > 1)
                return $"{(int)tiempo.TotalHours} horas";
            return $"{(int)tiempo.TotalMinutes} minutos";
        }

    }
}

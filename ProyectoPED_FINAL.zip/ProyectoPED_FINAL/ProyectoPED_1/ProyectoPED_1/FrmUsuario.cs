﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoPED_1
{
    public partial class FrmUsuario : Form
    {
        //referencia al formulario principal para regresar al mismo
        private FrmMenu menu;

        private ListaEnlazada enlazada;
        public FrmUsuario(FrmMenu Menu)
        {
            InitializeComponent();
            menu = Menu; //asgina el formulario del menú principal al atributo de la clase
        }

        private void FrmUsuario_Load(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            menu.Show();//muestra el menu 
            this.Close();//cierra el form actual
        }


        private void btnAgregarLibro_Click(object sender, EventArgs e)
        {

        }

        //


        private void ConfigurarDataGridView()
        {
            // Configurar columnas del DataGridView
            DGVLibros.AutoGenerateColumns = false;

            //configura la columna del ID
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ID",
                HeaderText = "ID",
                DataPropertyName = "ID"
            });

            //configura la columna del titulo
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Titulo",
                HeaderText = "Título",
                DataPropertyName = "Titulo",
                Width = 200
            });

            //configura la columna del autor
            DGVLibros.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Autor",
                HeaderText = "Autor",
                DataPropertyName = "Autor",
                Width = 150
            });

            //configuracion para la columna de la fecha, dandole un formato
            DataGridViewTextBoxColumn colFecha = new DataGridViewTextBoxColumn();
            colFecha.Name = "FechaPublicacion";
            colFecha.HeaderText = "Fecha Publicación";
            colFecha.DataPropertyName = "FechaPublicacion";
            colFecha.DefaultCellStyle.Format = "dd/MM/yyyy";
            DGVLibros.Columns.Add(colFecha);

            //configuracion para la columna para verificar si esta disponible
            DataGridViewCheckBoxColumn colDisponible = new DataGridViewCheckBoxColumn();
            colDisponible.Name = "DisponibleParaReserva";
            colDisponible.HeaderText = "Disponible";
            colDisponible.DataPropertyName = "DisponibleParaReserva"; // Debe coincidir exactamente con la propiedad
            DGVLibros.Columns.Add(colDisponible);

        }


        private void ActualizarDGV()
        {
            //obtiene los libros y los muestra en el dgv
            var libros = enlazada.ObtenerLibros();
            DGVLibros.DataSource = null;
            DGVLibros.DataSource = enlazada.ObtenerLibros();

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtID.Text, out int id))
            {
                MessageBox.Show("Ingrese un ID válido.", "ID inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Libro libro = enlazada.BuscarLibro(id);
            if (libro != null)
            {
                MessageBox.Show($"Libro encontrado:\n\nTítulo: {libro.Titulo}\nAutor: {libro.Autor}\nDisponible: {(libro.Disponibilidad ? "Sí" : "No")}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Libro no encontrado.", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAgregarLibro_Click_1(object sender, EventArgs e)
        {
            if (!int.TryParse(txtID.Text, out int id))
            {
                MessageBox.Show("Ingrese un ID válido.", "ID inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Libro libro = enlazada.BuscarLibro(id);
            if (libro != null)
            {
                if (!libro.Disponibilidad)
                {
                    MessageBox.Show("El libro ya está reservado.", "Reserva no disponible", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                libro.Disponibilidad = false; // Reservar el libro
                MessageBox.Show("Libro reservado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ActualizarDGV(); // Refresca la vista
            }
            else
            {
                MessageBox.Show("Libro no encontrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}

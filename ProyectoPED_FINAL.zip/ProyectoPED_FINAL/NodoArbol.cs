﻿namespace ProyectoPED_1
{
    internal class NodoArbol
    {
        public Libro Valor { get; set; }
        public NodoArbol Izquierdo { get; set; }
        public NodoArbol Derecho { get; set; }


        public NodoArbol(Libro libro)
        {
            Valor = libro;
            Izquierdo = null;
            Derecho = null;
        }
    }
}

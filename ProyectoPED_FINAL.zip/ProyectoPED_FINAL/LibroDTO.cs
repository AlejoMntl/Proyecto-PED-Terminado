﻿namespace ProyectoPED_1
{
    internal class LibroDTO
    {
        public int ID { get; set; }
        public string Autor { get; set; }
        public string Titulo { get; set; }
        public int AñoPublicacion { get; set; }
        public bool Disponibilidad { get; set; }
    }
}
